#include <pthread.h>

struct station {
    int free_seats;
    int waiting_students;
    int next_student_turn;
    pthread_mutex_t mutex;
    pthread_cond_t bus_arrived_cond;
    pthread_cond_t student_boarded_cond;
};

void station_init(struct station *station) {
    station->free_seats = 0;
    station->waiting_students = 0;
    station->next_student_turn = 1;
    pthread_mutex_init(&station->mutex, NULL);
    pthread_cond_init(&station->bus_arrived_cond, NULL);
    pthread_cond_init(&station->student_boarded_cond, NULL);
}

void station_load_bus(struct station *station, int count) {
    pthread_mutex_lock(&station->mutex);
    station->free_seats = count;

    while (station->free_seats > 0 && station->waiting_students > 0) {
        pthread_cond_broadcast(&station->bus_arrived_cond);
        pthread_cond_wait(&station->student_boarded_cond, &station->mutex);
    }

    station->free_seats = 0;
    pthread_mutex_unlock(&station->mutex);
}

int station_wait_for_bus(struct station *station, int myticket, int myid) {
    pthread_mutex_lock(&station->mutex);
    station->waiting_students++;

    while (myticket != station->next_student_turn || station->free_seats == 0) {
        pthread_cond_wait(&station->bus_arrived_cond, &station->mutex);
    }

    station->waiting_students--;
    station->free_seats--;
    station->next_student_turn++;

    pthread_cond_signal(&station->student_boarded_cond);
    pthread_mutex_unlock(&station->mutex);

    return station->next_student_turn - 1;
}

